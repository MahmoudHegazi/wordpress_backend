<?php 
ju_custom_query();
?>
<!doctype html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>





<!-- Material form contact -->
<div class="card">

    <h5 class="card-header info-color white-text text-center py-4">
        <strong>Create Request</strong>
    </h5>

    <!--Card content-->
    <div class="card-body px-lg-5 pt-0">

        <!-- Form -->
        <form class="text-center" style="color: #757575;" method="POST" action="<?php echo $_SERVER["PHP_SELF"];?>">

            <!-- Name -->
            <div class="md-form mt-3">
			    <label for="request_date">تاريخ الطلب</label>
                <input type="text" name="request_date" id="input1" class="form-control">
                
            </div>

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_item">اسم الصنف</label>
                <input type="text" name="request_item" id="input2" class="form-control">
                
            </div>
			
            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_description">المواصفات</label>
                <input type="text" name="request_description" id="input3" class="form-control">
                
            </div>

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_project">اسم العميل/المشروع</label>
                <input type="text" name="request_project" id="input4" class="form-control">
                
            </div>

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_man_order">امر التصنيع</label>
                <input type="text" name="request_man_order" id="input5" class="form-control">
                
            </div>

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_number">رقم طلب المشتريات</label>
                <input type="text" name="request_number" id="input6" class="form-control">
                
            </div>

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_pr">pr</label>
                <input type="text" name="request_pr" id="input7" class="form-control">
                
            </div>			
			
			
            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_quantity">الوحدة</label>
                <input type="text" name="request_quantity" id="input8" class="form-control">
                
            </div>			

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_amout_buy">الكمية المطلوب شرائها</label>
                <input type="text" name="request_amout_buy" id="input9" class="form-control">
                
            </div>			

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_amout_accepted">الكمية المقبولة</label>
                <input type="text" name="request_amout_accepted" id="input10" class="form-control">
                
            </div>			

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_amout_remain">الكمية المتبقية</label>
                <input type="text" name="request_amout_remain" id="input11" class="form-control">
                
            </div>						

			            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_sent_date">تاريخ التسليم الفعلي</label>
                <input type="text" name="request_sent_date" id="input12" class="form-control">
                
            </div>		

            <!-- E-mail -->
            <div class="md-form">
			    <label for="request_supplier_name">اسم المورد</label>
                <input type="text" name="request_supplier_name" id="input13" class="form-control">
                
            </div>					

            <!--Message-->
            <div class="md-form">
			    <label for="request_permision_number">رقم اذن التسليم</label>
                <textarea  name="request_permision_number" id="input14" class="form-control md-textarea" rows="3"></textarea>                
            </div>			
            <!--Message-->
            <div class="md-form">
			    <label for="request_notes">ملحظات</label>
                <textarea name="request_notes" id="input15" class="form-control md-textarea" rows="3"></textarea>                
            </div>						
			
			

            <!-- Copy -->
			<!--
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="materialContactFormCopy">
                <label class="form-check-label" for="materialContactFormCopy">Send me a copy of this message</label>
            </div>
             -->
            <!-- Send button -->
            <button class="btn btn-outline-info btn-rounded btn-block z-depth-0 my-4 waves-effect" type="submit">Send</button>

        </form>
        <!-- Form -->

    </div>

</div>
<!-- Material form contact -->
</body>
</html>


