<?php 
function ju_custom_query() {
global $wpdb;
//$user_count = $wpdb->get_var( "SELECT COUNT(*) FROM $wpdb->posts" );
//echo "<p>User count is {$user_count}</p>";


if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (!empty($_POST["request_date"])) {
  $input1 = $_POST["request_date"];
  $input2 = $_POST["request_item"];
  $input3 = $_POST["request_description"];
  $input4 = $_POST["request_project"];
  $input5 = $_POST["request_man_order"];
  $input6 = $_POST["request_number"];
  $input7 = $_POST["request_pr"];
  $input8 = $_POST["request_quantity"];
  $input9 = $_POST["request_amout_buy"];
  $input10 = $_POST["request_amout_accepted"];
  $input11 = $_POST["request_amout_remain"];
  $input12 = $_POST["request_sent_date"];
  $input13 = $_POST["request_supplier_name"];
  $input14 = $_POST["request_permision_number"];
  $input15 = $_POST["request_notes"];


  //$fuk = $wpdb->query($wpdb->prepare( "INSERT INTO $wpdb->mh_prequests (request_date, request_item, request_description, request_project, request_man_order, request_number, request_pr, request_quantity, request_amout_buy, request_amout_accepted, request_amout_remain, request_sent_date, request_supplier_name, request_permision_number, request_notes) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", array( 'hhh', 'hhhh', 'hh', 'hhh', 'hhh', 'hhh', 'hhh', 'hhh', 'hh', 'gg', 'gg', 'gg', 'gg', 'gg', 'gg' ) ) );
 



  // prepare and bind
  //$wpdb->show_errors();
   $stmt = $wpdb->query("INSERT INTO $wpdb->mh_prequests (request_date, request_item, request_description, request_project, request_man_order, request_number, request_pr, request_quantity, request_amout_buy, request_amout_accepted, request_amout_remain, request_sent_date, request_supplier_name, request_permision_number, request_notes) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", array('hhh', 'hhhh', 'hh', 'hhh', 'hhh', 'hhh', 'hhh', 'hhh', 'hh', 'gg', 'gg', 'gg', 'gg', 'gg', 'gg'));
  //$stmt->bind_param("ss", $user, $pass);
   //$wpdb->query($stmt);


}
}
}
?>

